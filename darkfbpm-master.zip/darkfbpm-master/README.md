pkg install git python2

pip2 install --upgrade pip

git clone https://github.com/zafarking788/darkfbpm

cd darkfbpm.py

pip2 install -r requirements.txt

python2 darkfbpm.py
